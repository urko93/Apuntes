// @Repository
package datos.dao;

import java.io.File;
import java.util.Date;

import java.util.List;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import datos.modelo.*;

import org.springframework.core.io.ClassPathResource;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import logicaNegocio.ServidorGestorBiblioHibernate;
import logicaNegocio.GestorBiblio;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class DbHibernate {
	public @interface Transactional {

	}




	private final static Logger log = Logger.getLogger(DbHibernate.class);
	private static SessionFactory sessionFactory;
	private static Session session;
	private static DbHibernate dbHibernate;
	private static HibernateTemplate ht;

	
public DbHibernate(){ 
	
}
public DbHibernate(SessionFactory sessionFactory){ // SE INICIALIZAR� CON UNA INYECCI�N DE DEPENDENCIA EN SPRING
	try{	
		this.sessionFactory = sessionFactory;
	
		System.out.println("CREACI�N DE DbHibernate: He inyectado la sessionFactory a DbHibernate: "+sessionFactory.toString());
		ht = new HibernateTemplate(this.sessionFactory);
		//System.out.println("He creado un HibernateTemplate : "+ht.toString());
		abrirBD();
		inicializarBD();
		
	}	catch(Exception e){System.out.println("Error en constructor DbHibernate: "+e.toString());}
}

public void setSessionFactory(SessionFactory sessionFactory){ // SE INICIALIZAR� CON UNA INYECCI�N DE DEPENDENCIA EN SPRING
	try{	
		this.sessionFactory = sessionFactory;
	
		System.out.println("He inyectado la sessionFactory a DbHibernate: "+sessionFactory.toString());
		ht = new HibernateTemplate(this.sessionFactory);
		abrirBD();
		inicializarBD();

	}	catch(Exception e){System.out.println("Error en constructor DbHibernate: "+e.toString());}
}
	
public SessionFactory getSessionFactory(){ // SE INICIALIZAR� CON UNA INYECCI�N DE DEPENDENCIA EN SPRING
	
		return sessionFactory;
}

public void abrirBD(){
	try{	
		BasicConfigurator.configure();
		Logger.getLogger("org.hibernate").setLevel(Level.WARN); 
		sessionFactory.openSession();
		System.out.println("Abierta la sesi�n en DBHibernate: "+sessionFactory.toString());		

		//session = sessionFactory.getCurrentSession();
		}
	catch(Exception e){System.out.println("Este es el churrillo: "+e.toString());}
}

public void cerrarBD(){
	sessionFactory.close();
	System.out.println("Cerrada la sesi�n en DBHibernate: "+sessionFactory.toString());
}

@Transactional
public void inicializarBD(){
	ht.deleteAll(ht.loadAll(Copia.class));
	ht.deleteAll(ht.loadAll(Reserva.class));
	ht.deleteAll(ht.loadAll(Socio.class));
	ht.deleteAll(ht.loadAll(Libro.class));
	Libro lib1 = createAndStoreLibro("La Biblia","1");
	Libro lib2 = createAndStoreLibro("El Cor�n","2");
	Copia c11 = addCopiaToLibro("1",lib1);
	Copia c21 = addCopiaToLibro("2",lib1);
	Copia c12 = addCopiaToLibro("1",lib2);
	Copia c22 = addCopiaToLibro("2",lib2);
	Copia c32 = addCopiaToLibro("3",lib2);
	
	Socio soc1 = createAndStoreSocio(1,"Jes�s");
	Socio soc2 = createAndStoreSocio(2,"Mahoma");
	Socio soc3 = createAndStoreSocio(3,"Benedicto");
	
	
	createAndStorePrestamo(soc1,c11);
	createAndStorePrestamo(soc3,c12);
	createAndStorePrestamo(soc2,c21);
	createAndStorePrestamo(soc3,c22);
	//createAndStorePrestamo(soc3,c23);
	
	createAndStoreReserva(soc1,lib2);
	createAndStoreReserva(soc2,lib1);

}

private Libro createAndStoreLibro(String titulo, String signatura) {
	//session = sessionFactory.getCurrentSession(); // NECESARIO SIEMPRE DESPU�S DE HABER HECHO UN COMMIT EN LA BD
	//session.beginTransaction();
	Libro elLibro = new Libro();
	elLibro.setSignatura(signatura);
	elLibro.setTitulo(titulo);
	ht.save(elLibro);
	//session.save(elLibro);
	//session.getTransaction().commit();
	log.info("Insertado: "+elLibro);
	return elLibro;
}


private Copia addCopiaToLibro(String numCopia, Libro lib) {
	//session = sessionFactory.getCurrentSession();
	//session.beginTransaction();
	CopiaId copiaId = new CopiaId(numCopia,lib.getSignatura());
	Copia copia = new Copia();
	copia.setId(copiaId);
	copia.setEstado("disponible");
	lib.getCopias().add(copia);
	ht.save(copia);
	ht.update(lib);
	//session.save(copia);  
	//session.update(lib);  
	//session.getTransaction().commit();
	log.info("Insertada: "+copia);
	log.info("A�adida a "+lib);
	return copia;
}

private Socio createAndStoreSocio(int numSocio, String nombre) {
	//session = sessionFactory.getCurrentSession();
	//session.beginTransaction();
	Socio elSocio = new Socio(numSocio,nombre);
	elSocio.setNumMaxPrest(2);
	ht.save(elSocio);
	//session.save(elSocio);
	//session.getTransaction().commit();
	log.info("Insertado: "+elSocio);
	return elSocio;
}
	
private Copia createAndStorePrestamo(Socio soc, Copia copia) {  // REHACER EL M�TODO CON LOS VALORES EN VEZ DE IDENTIFICADORES OBJETOS
	//session = sessionFactory.getCurrentSession();
	//session.beginTransaction();
	copia.setSocio(soc);
	copia.setEstado("ocupada");
	copia.setFechaPrestamo(new Date());
	ht.update(copia);
	//session.update(copia);
	//session.getTransaction().commit();
	log.info("Modificada: "+copia);
	return copia;
}

private Reserva createAndStoreReserva(Socio soc, Libro lib) {  // REHACER EL M�TODO CON LOS VALORES EN VEZ DE IDENTIFICADORES OBJETOS
	//session = sessionFactory.getCurrentSession();
	//session.beginTransaction();
	ReservaId resId = new ReservaId(lib.getSignatura(),soc.getNumSocio());
	Reserva res = new Reserva();
	res.setId(resId);
	res.setLibro(lib);
	res.setSocio(soc);
	res.setFechaReserva(new Date());
	res.setDisponible("N");
	lib.getReservas().add(res);
	ht.save(res);
	//session.save(res);
	//session.getTransaction().commit();
	log.info("Insertada: "+res);
	return res;
}

private List<Libro> listLibros() {
	//session = sessionFactory.getCurrentSession();
	//session.beginTransaction();
	//List<Libro> result = (List<Libro>)session.createQuery("from Libro").list();
	List<Libro> result = (List<Libro>)ht.find("from Libro");
	//session.getTransaction().commit();
	for (Libro lib : result) {
		// System.out.println("Le�do: "+lib.getSignatura()+" "+lib.getTitulo());
		log.info("Leido: "+lib.getSignatura()+" "+lib.getTitulo());
	}
	return result;
	}


public Libro getLibro(String sign){

	/*
	session = HibernateUtil.getSessionFactory().getCurrentSession();
	session.beginTransaction();
	List<Libro> result = (List<Libro>)session.createQuery("from Libro").list();
	session.getTransaction().commit();
	for (Libro lib : result) {
		if (lib.getSignatura().equals(sign)) return lib;
	}
	return null;
	*/


	//session = sessionFactory.getCurrentSession();
	//session.beginTransaction();
	//List<Libro> result = (List<Libro>)session.createQuery("from Libro where signatura='"+sign+"'").list();
	List<Libro> result = (List<Libro>)ht.find("from Libro where signatura='"+sign+"'");
	//session.getTransaction().commit();
	if (result.isEmpty())return null;
	else return (Libro) result.get(0);


}


public Socio getSocio(int ns){

	//session = sessionFactory.getCurrentSession();
	//session.beginTransaction();
	//List<Socio> result = (List<Socio>)session.createQuery("from Socio where numSocio="+ns).list();
	List<Socio> result = (List<Socio>)ht.find("from Socio where numSocio="+ns);
	//session.getTransaction().commit();
	if (result.isEmpty())return null;
	else return result.get(0);
}


public void newPrestamo(Socio s,Copia c){
	createAndStorePrestamo(s,c);
}

public Copia getCopia(String sign, String numCopia){

	//session = sessionFactory.getCurrentSession();
	//session.beginTransaction();
	//List<Copia> result = (List<Copia>)session.createQuery("from Copia where suLibro='"+sign+"' and numCopia='"+numCopia+"'").list();
	List<Copia> result = (List<Copia>)ht.find("from Copia where suLibro='"+sign+"' and numCopia='"+numCopia+"'");
	//session.getTransaction().commit();
	if (result.isEmpty())return null;
	else return result.get(0);
}

public Copia getCopiaLibre(Libro sign, Socio s){

	//session = sessionFactory.getCurrentSession();
	//session.beginTransaction();
	//List<Copia> result = (List<Copia>)session.createQuery("from Copia where suLibro='"+sign.getSignatura()+"' and estado='disponible'").list();
	List<Copia> result = (List<Copia>)ht.find("from Copia where suLibro='"+sign.getSignatura()+"' and estado='disponible'");
// FALTA COMPROBAR LO DE QUE EL SOCIO NO LA TIENE RESERVADA
	
	//session.getTransaction().commit();
	if (result.isEmpty())return null;
	else return result.get(0);
}

public boolean isMaximo(Socio s){
	// Suponemos que el socio s existe, si no devolver�a true (para impedir el pr�stamo a un socio inexistente)

	System.out.println("SOCIO: "+s.getNumSocio()+" NumMaxPrest: "+s.getNumMaxPrest());
	if (s.getNumMaxPrest()>s.getCopias().size()) return false;
	else return true;

	/*
	List<Copia> result1 = (List<Copia>)ht.find("from Copia where prestadaA="+s.getNumSocio()+" and estado='ocupada'");
	List<Socio> result2 = (List<Socio>)ht.find("from Socio where numSocio="+s.getNumSocio());
	if (result2.isEmpty()) return true;
	else 
	// FALTA COMPROBAR LO DE QUE EL SOCIO NO LA TIENE RESERVADA
		
		//session.getTransaction().commit();
		if (result.isEmpty())return null;
		else return result.get(0);
	*/
}


public static void main(String[] args) {
	try {
		
		
		
		ClassPathResource resource = new ClassPathResource("applicationContext.xml");
		BeanFactory beanFactory = new XmlBeanFactory(resource);
		//Object obj = (Object) beanFactory.getBean("dBHibernateService");
		//System.out.println("Esto ha colado: "+obj.toString());
		GestorBiblio serv = (GestorBiblio) beanFactory.getBean("dBHibernateService");
		//System.out.println("Esto ha colado: "+serv.toString());
		dbHibernate = serv.getDb();
		dbHibernate.abrirBD();
		dbHibernate.inicializarBD();
		System.out.println("Inicializada la BD ");
		//dbHibernate.cerrarBD();
		Libro l = dbHibernate.getLibro("1");
		System.out.println("getLibro(1): "+l.toString());
		Socio s = dbHibernate.getSocio(1);
		System.out.println("getSocio(1): "+s.toString());
		dbHibernate.newPrestamo(dbHibernate.getSocio(3),dbHibernate.getCopia("2","3"));
		dbHibernate.cerrarBD();
		System.out.println("Termino bien!");
	} catch(Exception e) {System.out.println("Error: "+e.toString());}
}

}