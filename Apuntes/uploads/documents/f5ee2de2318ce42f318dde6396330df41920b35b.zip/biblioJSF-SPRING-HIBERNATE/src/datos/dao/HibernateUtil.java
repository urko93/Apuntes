// ESTA CLASE QUE SERV�A PARA OBTENER EL sessionFactory desde hibernate.cfg.xml
// Y SE LLAMABA DESDE DBHibernate.java YA NO ES NECESARIA
// EN DBHibernate.java SE "INYECTAR�" el sessionFactory DEFINI�NDOLO COMO UN BEAN.

package datos.dao;
import java.io.File;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class HibernateUtil {
private static final SessionFactory sessionFactory;
static {
try {
// Create the SessionFactory from hibernate.cfg.xml
	
	//El fichero de configuraci�n "hibernate.cfg.xml" TIENE QUE ESTAR EN EL DIRECTORIO "RA�Z" DEL PROYECTO
	// y no en el subdirectorio "src"
	sessionFactory = new Configuration().configure(new File("hibernate.cfg.xml")).buildSessionFactory();
} catch (Throwable ex) {
// Make sure you log the exception, as it might be swallowed
throw new ExceptionInInitializerError(ex);
}
}
public static SessionFactory getSessionFactory() {
return sessionFactory;
}
}