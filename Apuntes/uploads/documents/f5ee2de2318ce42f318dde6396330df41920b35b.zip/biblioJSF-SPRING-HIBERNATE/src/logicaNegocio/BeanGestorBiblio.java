package logicaNegocio;


public interface BeanGestorBiblio {
	
	public void setHost(String host);

	public String getHost();

	public void setPuerto(int puerto);

	public int getPuerto();

	public void setNombreServicio(String nombreServicio);

	public String getNombreServicio();
	
	public void setFicheroPoliticaSeguridad(String ficheroPoliticaSeguridad);

	public String getFicheroPoliticaSeguridad();
		
	public int tomarPrestamo(String numSocio, String sign); 
	// OPERACI�N DE LA L�GICA DEL NEGOCIO
	// SE PODR�AN A�ADIR: setNumSocio, setSign, getResultado PARA QUE SE UTILIZARA COMO BEAN
	// PERO NO LO HAGO PARA MANTENER LA ESTRUCTURA ANTERIOR
}
