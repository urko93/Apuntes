package logicaNegocio;

import java.rmi.Naming;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class BeanGestorBiblioImplHibernate  
	implements BeanGestorBiblio {
	String host;
	int puerto;
	String nombreServicio;
	String ficheroPoliticaSeguridad;
	
	GestorBiblio g;
	
	public BeanGestorBiblioImplHibernate() 
	{
		// System.out.println("Creando instancia de BeanGestorBiblioImplHibernate en CONSTRUCTOR VAC�O");
	}
	
	public BeanGestorBiblioImplHibernate(String host, int puerto, String nombreServicio, String ficheroPoliticaSeguridad) 
	{
	try{
		//System.out.println("Creando instancia de BeanGestorBiblioImplHibernate en CONSTRUCTOR con 4 par�metros");
		//System.out.println("host:"+host+" puerto: "+puerto+"nombreServicio: "+nombreServicio+" ficheroPoliticaSeguridad: "+ficheroPoliticaSeguridad);
		if (host.equals("localhost")) {
			// g = new ServidorGestorBiblioHibernate(); SE HACE CARGANDO EL BEAN DE SPRING
			ClassPathResource resource = new ClassPathResource("applicationContext.xml");
			BeanFactory beanFactory = new XmlBeanFactory(resource);
			g = (GestorBiblio) beanFactory.getBean("dBHibernateService");
			//System.out.println("He creado dBHibernateService dentro de BeanGestorBiblioImplHibernate: "+g.toString());
		}
		else {
			System.setProperty("java.security.policy",ficheroPoliticaSeguridad);
			  try{
			  		  g = (GestorBiblio) Naming.lookup("rmi://"+host+":"+puerto+"/"+nombreServicio);
			  } catch(Exception e) {
			  System.out.println("Error al conseguir la l�gica del negocio: "+  e.toString());}
		} 
	} catch (Exception e) {System.out.println("Error en BeanGestorBiblioImplHibernate: "+e.toString()); }
	}
	
	public void setHost(String host) {this.host=host;}

	public String getHost() { return host;}

	public void setPuerto(int puerto) {this.puerto=puerto;}

	public int getPuerto() { return puerto;}

	public void setNombreServicio(String nombreServicio) {this.nombreServicio=nombreServicio;}

	public String getNombreServicio() { return nombreServicio;}
	
	public void setFicheroPoliticaSeguridad(String ficheroPoliticaSeguridad) {this.ficheroPoliticaSeguridad=ficheroPoliticaSeguridad;}

	public String getFicheroPoliticaSeguridad() { return ficheroPoliticaSeguridad;}

	
	public int tomarPrestamo(String numSocio, String sign) {
	try{
		return g.tomarPrestamo(numSocio, sign);
	}  catch (Exception e) {System.out.println("Error en BeanGestorBiblioImplHibernate: "+e.toString()); 
							return -5;}
	}

}
