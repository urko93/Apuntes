package logicaNegocio;

import java.rmi.*;

import datos.dao.DbHibernate;

public interface GestorBiblio extends Remote{

		int tomarPrestamo(String numSocio, String sign) throws RemoteException;
		public DbHibernate getDb() throws RemoteException;
}
