package logicaNegocio;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import datos.dao.DbHibernate;

import datos.modelo.*;

public class ServidorGestorBiblioHibernate extends UnicastRemoteObject 
									implements GestorBiblio {
	DbHibernate db; // Este es el DAO, que hay que inyectar
	
	protected ServidorGestorBiblioHibernate() throws RemoteException {
		super();
		System.out.println("Estoy pasando por la creaci�n de ServidorGestorBiblioHibernate");
		//db.abrirBD();
		//db.inicializarBD();
		// TODO Auto-generated constructor stub
	}


	public DbHibernate getDb() throws RemoteException{
		
		// System.out.println("No s� qui�n me ha llamado pero devuelvo el DbHibernate: "+db.toString());
		return db;
	}


	public void setDb(DbHibernate db) {
		// System.out.println("No s� qui�n me ha llamado pero le ASIGNO el DbHibernate: "+db.toString());
		this.db = db;
	}

	
	public int tomarPrestamo(String numSocio, String sign) throws RemoteException {
		// TODO Auto-generated method stub
		//System.out.println("Solicitud libro, numSocio:" +numSocio+" sign:"+sign);
		Libro l = db.getLibro(sign);
		//System.out.println("LIBRO: "+l.toString());
		if (l==null) return -3; // LIBRO INEXISTENTE
		Socio s = db.getSocio(Integer.parseInt(numSocio));
		//System.out.println("SOCIO: "+s.toString());
		if (s==null) return -4; // SOCIO INEXISTENTE
		// Copia c = l.getCopiaLibre(s);	ESTE M�TODO NO EST� EN LA CLASE Copia. Lo ponemos en DBHibernate
		Copia c = db.getCopiaLibre(l,s);
		System.out.println("COPIA: "+c);
		if (c==null) return -1; // NO HAY COPIA LIBRE
		//if (s.isMaximo()) return -2; // HA LLEGADO AL M�XIMO
		if (db.isMaximo(s)) return -2;
		db.newPrestamo(s, c);
		// return Integer.parseInt(c.getNumCopia()); // HIBERNATE ha cambiado el m�todo getNumCopia porque ha introducido una clase CopiaId
		return Integer.parseInt(((CopiaId)c.getId()).getNumCopia());
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		GestorBiblio objetoServidor;
		
		try { 
		ClassPathResource resource = new ClassPathResource("applicationContext.xml");
		BeanFactory beanFactory = new XmlBeanFactory(resource);
		objetoServidor = (GestorBiblio) beanFactory.getBean("dBHibernateService");
		} catch (Exception e) 
		 {System.out.println("Error al lanzar el servidor: "+e.toString());}
	

	}





}
