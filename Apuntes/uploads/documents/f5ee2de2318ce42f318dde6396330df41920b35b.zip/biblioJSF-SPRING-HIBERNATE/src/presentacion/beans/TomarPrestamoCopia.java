package presentacion.beans;

import java.rmi.Naming;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import datos.modelo.Libro;
import datos.modelo.Socio;

import logicaNegocio.BeanGestorBiblio;
import logicaNegocio.GestorBiblio;

public class TomarPrestamoCopia {

	private int numSocio;
	private String signatura="";
	private String mensaje="";
	private String numCopia="";
	BeanGestorBiblio g;
	//private String copia="";
	
public TomarPrestamoCopia() {
		
		// System.out.println("CREADA INSTANCIA de TomarPrestamo Copia");
		
		ApplicationContext appContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		BeanFactory beanFactory = appContext;
		g = (BeanGestorBiblio) beanFactory.getBean("beanGestorLibro");
		// System.out.println("Creado el beanGestorLibro");
		
		/*
		System.setProperty("java.security.policy","D:\\java.policy");
		  try{
		  		  g = (GestorBiblio) Naming.lookup("rmi://localhost:1099/gestorLibro");
		  } catch(Exception e) {
		  System.out.println("Error al conseguir la l�gica del negocio: "+  e.toString());}
		*/
	}

	public void setNumSocio(int ns) {
		numSocio=ns;
	}
	
	public int getNumSocio() {
		return numSocio;
	}
	
	public void setSignatura(String s) {
		signatura=s;
	}
	
	public String getSignatura() {
		return signatura;
	}
	
	public String getMensaje() {
		return mensaje;		
	}

	public String getCopia() {
		try {
			System.out.println("Voy a llamar a la l�gica del negocio");
			int res = g.tomarPrestamo(Integer.toString(numSocio), signatura);
			System.out.println("He llamado a la l�gica del negocio");
			if (res==-1) return mensaje = "No hay copias libres";
			else if (res==-2) return mensaje = "Superado el m�ximo de pr�stamos";
			else if (res==-3) return mensaje = "Libro inexistente";
			else if (res==-4) return mensaje = "Socio inexistente";
			else if (res>=0) { mensaje = "Tomada en pr�stamo la copia: "+res;
							   numCopia = Integer.toString(res); 
							   return "ok";}		
		} catch(Exception ex) {	mensaje = "Error: "+ex.toString(); 
								return "error";}
		mensaje = "Error inesperado";
		return "error";
	}
	
	//public void setCopia(String cop) {
	//	copia="";
	//}
	
	public String getNumCopia() {
		return numCopia;
	}
	
	public static void main(String[] args) {
		try {
			//System.out.println("Voy a a crear instancia de TomarPrestamoCopia");
			TomarPrestamoCopia tpc = new TomarPrestamoCopia();		
			//System.out.println("Ya he creado copia de TomarPrestamoCopia");

			
		} catch(Exception e) {System.out.println("Error: "+e.toString());}
	}
}
